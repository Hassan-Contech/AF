﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using ComponentsLibrary.UI.DBWork;
using ComponentsLibrary.UI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace ComponentLibrary.ViewComponents
{
    public class AdvancedFilters : ViewComponent
    {
        private readonly IConfiguration Configuration;
        private string dbConnectionString;

        public AdvancedFilters(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            dbConnectionString = Configuration.GetValue<string>("ConnectionStrings:DefaultConnection");

            List<Region> regions = await GetRegions();

            return View(regions);
        }

        public Task<List<Region>> GetRegions()
        {
            DataSet regionsDS = DBHelper.ExecuteProcedureReturnDataSet(dbConnectionString, "GetRegions");
            List<Region> regionList = regionsDS.Tables[0].AsEnumerable()
                .Select(dataRow => new Region
                {
                    RegionNameEnglish = dataRow.Field<string>("RegionNameEnglish")
                }).ToList();

            return Task.FromResult(regionList);
        }

    }
}
