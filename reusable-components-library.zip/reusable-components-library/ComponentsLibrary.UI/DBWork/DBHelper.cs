﻿using System.Data;
using System.Data.SqlClient;

namespace ComponentsLibrary.UI.DBWork
{
    public class DBHelper
    {
		public static DataSet ExecuteProcedureReturnDataSet(string connString, string procName,
			params SqlParameter[] paramters)
		{
			DataSet result = null;
			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.StoredProcedure;
						command.CommandText = procName;
						if (paramters != null)
						{
							command.Parameters.AddRange(paramters);
						}
						result = new DataSet();
						sda.Fill(result);
					}
				}
			}
			return result;
		}
	}
}
